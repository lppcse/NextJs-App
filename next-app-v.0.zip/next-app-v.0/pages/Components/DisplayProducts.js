
import { gql } from '@apollo/client';

function DisplayProducts(client) {

    client.query({ query: gql`
    {
      user(id: 1) {
        id
        name
      }
    }
  `}).then(res => {
    const { data } = res;
    console.log('logged the fetched data', data);
  });
    return (
            <>
                 <h1>List of Products : </h1>
                <h1>Data from Server : {}</h1>
                <ul>
                    <li>Name: {}</li>
                    <li>User: {}</li>
                    <li>Id: {}</li>
                </ul>
            </>
    )
}

export default DisplayProducts;